# Acompanhamento

Marque com um "x" nas caixas abaixo quais as áreas de perguntas que tentou:

 - [ ] 01-Lógica
 - [ ] 02-AWS
 - [ ] 03-Linux