1. Bob pede a Alice para suspender uma instância EC2 no console da AWS, pois não utilizará mais naquele momento, apenas na próxima semana. Qual a terminologia utilizada para suspender essa instância?
   * [ ] Terminar
   * [ ] Finalizar
   * [ ] Encerrar
   * [ ] Interromper

2. Bob precisa liberar a porta 22 (SSH) para se conectar na instância EC2. Qual serviço o Bob precisa configurar para que essa porta seja liberada?
   * [ ] Security Groups
   * [ ] Network Access Control List
   * [ ] Firewall
   * [ ] VPC

3. Alice otimizou as instâncias EC2 e agora precisa deletar uma delas. Qual a terminologia utilizada para finalizar a instância?
   * [ ] Finalizar
   * [ ] Terminar
   * [ ] Encerrar
   * [ ] Interromper

4. Alice precisar armazenar uma grande quantidade de objetos para que depois possa acessá-los em qualquer lugar. Qual o serviço mais indicado?
   * [ ] EBS
   * [ ] EC2
   * [ ] S3
   * [ ] HDD

5. Bob precisa configurar um banco de dados relacional no console da AWS. Qual o serviço mais indicado?
   * [ ] EC2
   * [ ] EBS
   * [ ] Lambda
   * [ ] RDS

5. Quais serviços e arquitetura você utilizaria, e onde empregaria cada serviço, na AWS, para fazer o deploy de uma loja virtual com uma média de 1mil visitas diárias, quando:
   1. Dinheiro não fosse o problema
      * Resposta: 
   2. Você tivesse um orçamento máximo de US$100,00
      * Resposta: 
      