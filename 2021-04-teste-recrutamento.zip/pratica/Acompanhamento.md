# Acompanhamento

Marque com um "x" nas caixas abaixo quais os testes completos:

 - [ ] 01-smart-staff
 - [ ] 02-inversao-array
 - [ ] 03-juntar-arrays
 - [ ] 04-contagem-array
 - [ ] 05-voltas-no-array
 - [ ] 06-CRUD