# Desafio

Faça um script/sistema, em qualquer linguagem de programação, que junte/mescle/una os arrays abaixo, seguindo a ordem apresentada (não é permitido utilizar funções prontas da linguagem/framework/biblioteca):

 - `[0, 1, 2, 3, 4, 5]`
 - `['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']`
 - `[6, 7, 8, 9, 10]`

# Documentação

Atualize este README sobre como rodar em desenvolvimento e como efetuar o deploy, se aplicável.