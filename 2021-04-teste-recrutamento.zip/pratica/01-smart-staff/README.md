# Desafio

Faça um script/sistema, em qualquer linguagem de programação, que escreva todos os número de -71 até 103. Para os números múltiplos de 3, escreva "Smart", para os números múltiplos de 5, escreva "Staff".

# Documentação

Atualize este README sobre como rodar em desenvolvimento e como efetuar o deploy, se aplicável.