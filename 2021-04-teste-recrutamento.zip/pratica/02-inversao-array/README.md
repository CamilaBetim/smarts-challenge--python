# Desafio

Faça um script/sistema, em qualquer linguagem de programação, que faça a inversão do um array alfanumérico abaixo (não é permitido utilizar funções prontas da linguagem/framework/biblioteca):

`['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']`

# Documentação

Atualize este README sobre como rodar em desenvolvimento e como efetuar o deploy, se aplicável.